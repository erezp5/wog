from app import start_play, welcome

quit = False
username = input("Please enter your name: ")
while not quit:
    welcome(username)
    start_play()

    play_again = input(f"{username}, do you want to play again? (y/n): ")
    if play_again.lower() == "n":
        quit = True
        print("Thanks for playing!")
