
games = [
    {
        "id": 1, 
        "title": "Memory Game", 
        "description": "a sequence of numbers will appear for 1 second and you have to guess it back."
    }, 
    {
        "id": 2, 
        "title": "Guess Game",
        "description": "guess a number and see if you chose like the computer."
    }, 
    {
        "id": 3, 
        "title": "Currency Roulette",
        "description": "try and guess the value of a random amount of USD in ILS"
    }
]

def welcome(username):
    print(f"Hi {username} and welcome to the World of Games: The Epic Journey")
    

def start_play():
    
    print("Please choose a game to play:")
    for game in games:
        print(f"{game['id']}. {game['title']} - {game['description']}")
    game_id = input("> ")

    game_ids = [game['id'] for game in games]
    if game_id.isdigit() and int(game_id) in game_ids:
        selected_game = next((game for game in games if game['id'] == int(game_id)), None)
        if selected_game:
            print(f"You selected the game: {selected_game['title']}")
            # Add game logic here
        else:
            print("Invalid game selection.")
            return
    else:
        print("Invalid game selection.")
        return

    game_difficult = input("select a difficulty level between 1 and 5: ")
    if game_difficult.isdigit() and int(game_difficult) in range(1, 5):
        print(f"You selected difficulty level: {game_difficult}")
    else: 
        print("Invalid difficulty selection.")
        return

